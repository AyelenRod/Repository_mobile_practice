fun Valores() {
    val x = "Hola"
    val y = "Martha"

    println("Valor inicial de X: $x y valor inicial de Y: $y")
    println("valor de x cambiado a $y y valor de y cambiado a $x ")
}


fun main(){
    println(Valores())
}
